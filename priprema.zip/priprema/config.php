<?php
define('HOST', 'localhost');
define('DBNAME', 'priprema');
define('USER', 'root');
define('PASS', '');